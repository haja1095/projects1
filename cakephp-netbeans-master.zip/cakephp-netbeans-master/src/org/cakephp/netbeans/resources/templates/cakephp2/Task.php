<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

/**
 * CakePHP ${name}
 * @author ${user}
 */
class ${name} extends Shell {

	public $uses = array();

	public function execute(){

	}
}
