<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

App::uses('AppModel', 'Model');

/**
 * CakePHP ${name}
 * @author ${user}
 */
class ${name} extends AppModel {

}
