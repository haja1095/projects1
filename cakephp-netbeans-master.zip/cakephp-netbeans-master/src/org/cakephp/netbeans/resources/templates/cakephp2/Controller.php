<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

App::uses('AppController', 'Controller');

/**
 * CakePHP ${name}
 * @author ${user}
 */
class ${name} extends AppController {

	public function index($id){

	}
}
