<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

/**
 * CakePHP ${name}
 * @author ${user}
 */
class ${name} extends Component {
	public $components = array();

	public function initialize($controller) {

	}

	public function startup($controller){

	}

	public function beforeRender($controller) {

	}

	public function shutDown($controller) {

	}

	public function beforeRedirect($controller, $url, $status = null, $exit = true) {

	}

}
