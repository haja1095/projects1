<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

/**
 * CakePHP Task
 * @author ${user}
 */
class ${name}Task extends Shell {

	public $uses = array();

	function execute(){

	}
}
