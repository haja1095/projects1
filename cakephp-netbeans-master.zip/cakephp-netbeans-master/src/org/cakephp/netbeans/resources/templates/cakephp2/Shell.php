<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

/**
 * CakePHP ${name}
 * @author ${user}
 */
class ${name} extends AppShell {

	public $uses = array();
	public $tasks = array();

	public function main(){

	}
}
